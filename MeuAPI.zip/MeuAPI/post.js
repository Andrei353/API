const axios  = require('axios');
const url = "https://jsonplaceholder.typicode.com/posts";

//Dados que  queremos enviar para API (Exemplo: um novo post)
const novoPost ={
    title: "Aprendendo integração de API",
    body: "Este é um Exemplo de como fazer uma requisição POST usando axios",
    userId: 1
}

//Fazendo uma requesição POST para criar um novo recurso na API
axios.post(url, novoPost).then(response =>{
     //Se a requisição foi bem-sucedida , a resposta da API estara aqui
     console.log("Recurso criado com sucesso: ")
     console.log(response.data)
})
.catch(error =>{
    //Se ocorrer erro, ele será capiturado aqui
    console.error(`Erro ao tentar criar o recurso: ${error}`)
})
