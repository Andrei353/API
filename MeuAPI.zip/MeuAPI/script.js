const axios  = require('axios')
const url = "https://jsonplaceholder.typicode.com/todos/1"

// Fazendo requisição get
axios.get(url).then(response =>{
    //Dados Recebidos da API
    console.log("Dados Recebidos da API: ")

    console.log(response.data)
})
.catch(erro => {
    //tratamento de erro
    console.log(`Erro ao acessar a API: ${error}`)
})
